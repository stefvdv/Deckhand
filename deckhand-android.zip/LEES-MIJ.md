# Deckhand Android-app — bron (vanaf 5.0)

Deze zip hoort in de root van de GitHub-repo als `deckhand-android.zip`.
Bij elke nieuwe versie van de zip bouwt GitHub de app
(`.github/workflows/apk.yml`) en zet `Deckhand.apk` in de repo-root.

- `app/build.gradle` — versie (`versionCode` / `versionName`) en de bibliotheken:
  ML Kit tekstherkenning (model in de app, werkt zonder Google Play Services)
  en CameraX.
- `app/src/main/java/.../Scanner.java` — de camera + tekstherkenning voor de
  kaartscanner (`window.DeckhandScan`).
- `signing.enc` — de ondertekensleutel, versleuteld. Het geheim
  `DECKHAND_KEY` in GitHub maakt hem open. Zelfde sleutel als alle eerdere
  APK's (SHA-256 85:EA:59:F3…), dus updates installeren over de oude app heen.

## Versies
- **5.0** — Kaartscanner met de eigen camera van de telefoon en Google ML Kit.
  Het camerabeeld ligt achter de pagina; de pagina laat er een gat voor open.
  Echte kleuren, autofocus, tik-om-scherp-te-stellen, lamp. Eerste versie die
  op GitHub gebouwd wordt (Gradle). Hoort bij Deckhand 1.28.
