package app.deckhand.companion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* Woken by the daily alarm, and again after a reboot (an alarm does not
   survive one, so it is re-armed there). The work happens off the main
   thread; goAsync() keeps the process alive while it runs. */
public class NotifyReceiver extends BroadcastReceiver {

    public static final String ACTION_CHECK = "app.deckhand.companion.CHECK";

    @Override
    public void onReceive(Context context, Intent intent) {
        final Context app = context.getApplicationContext();
        final String action = intent == null ? null : intent.getAction();

        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            if (Notifier.isEnabled(app)) Notifier.scheduleDaily(app);
            return;
        }

        if (!Notifier.isEnabled(app)) return;
        final PendingResult done = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                try { Notifier.runCheck(app); }
                finally { done.finish(); }
            }
        }).start();
    }
}
