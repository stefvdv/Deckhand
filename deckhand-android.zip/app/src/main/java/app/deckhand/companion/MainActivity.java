package app.deckhand.companion;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.WindowManager;
import android.database.ContentObserver;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    static final String HOST = "deckhandcompanion.netlify.app";
    static final String START = "https://" + HOST + "/";
    static final int FILE_REQ = 71;
    static final int PERM_REQ = 72;
    static final int CAM_REQ = 73;
    PermissionRequest pendingCam;
    /* The system splash may be held at most this long. Past it the app must
       show itself, logo or no logo -- a splash that never leaves is worse than
       a slow start. */
    static final long SPLASH_HOLD_MS = 10000;
    volatile boolean webPainted = false;
    long startedAt = 0;
    /* Our own copy of the launcher splash, laid over the WebView. It carries
       the same artwork at the same measured size, so whenever Android drops
       its splash this is already underneath and nothing changes on screen. */
    ImageView splashCover;

    WebView web;
    Scanner scanner;   // APK 5.0: native camera + ML Kit for the card scanner

    /* Table mode (the life counter): screen on, and a fixed brightness with
       the phone's auto-brightness left out. The level is given as a position
       on the phone's own brightness slider (65% = where the slider would
       sit), so what you ask for is what you see. Moving the phone's own
       slider while the counter is open hands control back to the phone. */
    boolean tableOn = false, tableHandedBack = false;
    float tableLevel = -1f;   // < 0: the phone decides (APK 3.7: no built-in default)
    ContentObserver brightObs = null;

    /* Android 9 and later draw the brightness slider on a perceptual curve,
       while a window asks for LINEAR brightness. Convert slider -> linear
       with the same curve the system slider uses (BrightnessUtils). */
    static float sliderToLinear(float x) {
        x = Math.max(0.02f, Math.min(1f, x));
        if (Build.VERSION.SDK_INT < 28) return x;
        final double R = 0.5, A = 0.17883277, B = 0.28466892, C = 0.55991073;
        double v = x <= R ? (x / R) * (x / R) : Math.exp((x - C) / A) + B;
        return (float) Math.max(0.01, Math.min(1.0, v / 12.0));
    }

    void applyTableMode() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        if (tableOn) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            lp.screenBrightness = (tableHandedBack || tableLevel < 0)
                ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                : sliderToLinear(tableLevel);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        }
        getWindow().setAttributes(lp);
    }

    void watchPhoneSlider(boolean on) {
        try {
            if (on && brightObs == null) {
                brightObs = new ContentObserver(new Handler(Looper.getMainLooper())) {
                    @Override public void onChange(boolean self) {
                        if (!tableOn || tableHandedBack) return;
                        tableHandedBack = true;   // you moved the phone's slider: yours now
                        applyTableMode();
                    }
                };
                getContentResolver().registerContentObserver(
                    Settings.System.getUriFor(Settings.System.SCREEN_BRIGHTNESS), false, brightObs);
            } else if (!on && brightObs != null) {
                getContentResolver().unregisterContentObserver(brightObs);
                brightObs = null;
            }
        } catch (Exception e) { /* no observer: the in-app control still works */ }
    }
    ValueCallback<Uri[]> fileCb;

    /* Injected on every page load:
       - anchor clicks (user taps AND programmatic a.click()) on blob: URLs with a
         download attribute are routed to the DeckhandExport bridge WITH their
         intended filename, so backups keep names like
         admirals-commanders-backup-2026-09-21.json. */
    static final String EXPORT_HOOK =
        "(function(){" +
        "if(window.__dhHook)return;window.__dhHook=1;" +
        "function grab(a){try{fetch(a.href).then(function(r){return r.blob();}).then(function(b){" +
        "var fr=new FileReader();fr.onload=function(){" +
        "DeckhandExport.save(String(fr.result).split(',')[1]||'',b.type||'',a.getAttribute('download')||'');};" +
        "fr.readAsDataURL(b);});}catch(e){}}" +
        "var oc=HTMLAnchorElement.prototype.click;" +
        "HTMLAnchorElement.prototype.click=function(){" +
        "if(this.href&&this.href.indexOf('blob:')===0&&this.hasAttribute('download')){grab(this);return;}" +
        "return oc.apply(this,arguments);};" +
        "document.addEventListener('click',function(e){" +
        "var n=e.target;while(n&&n.tagName!=='A')n=n.parentElement;" +
        "if(n&&n.href&&n.href.indexOf('blob:')===0&&n.hasAttribute('download')){e.preventDefault();grab(n);}" +
        "},true);" +
        "})();";

    /* Asks Android to keep ITS OWN splash on screen until the page has painted.
       Nothing is redrawn in between, so there is no second version of the logo
       to jump to. Android 12 and up only; older phones fall back on the window
       backdrop, which carries the same artwork at the same measured size. */
    /* Takes over the farewell of Android's splash screen.

       The platform offers exactly ONE lever here: setOnExitAnimationListener.
       When Android decides the splash may go it hands us the view instead of
       removing it, and from that moment it is ours -- it stays on screen for
       as long as we do not remove it. That is how you hold a splash screen on
       the platform API.

       (setKeepOnScreenCondition, which this code called until 2.7, belongs to
       androidx.core.splashscreen and does NOT exist in Android itself. The
       ClassNotFoundException it threw aborted the whole block, so the listener
       below was never installed either -- which is why every attempt to hold
       the splash did nothing at all. Hence: one try per call, always.) */
    void holdSystemSplash() {
        if (Build.VERSION.SDK_INT < 31) return;
        try {
            Object splash = Activity.class.getMethod("getSplashScreen").invoke(this);
            final Class<?> exit = Class.forName("android.window.SplashScreen$OnExitAnimationListener");
            Object bye = Proxy.newProxyInstance(exit.getClassLoader(), new Class<?>[]{ exit },
                new InvocationHandler() {
                    @Override public Object invoke(Object p, Method m, Object[] args) {
                        String n = m.getName();
                        if ("onSplashScreenExit".equals(n)) {
                            handOverSplash((args != null && args.length > 0) ? args[0] : null);
                            return null;
                        }
                        if ("hashCode".equals(n)) return System.identityHashCode(p);
                        if ("equals".equals(n)) return p == (args != null ? args[0] : null);
                        if ("toString".equals(n)) return "DeckhandSplashExit";
                        return null;
                    }
                });
            Class.forName("android.window.SplashScreen")
                 .getMethod("setOnExitAnimationListener", exit)
                 .invoke(splash, bye);
        } catch (Throwable t) { /* our own layer carries it instead */ }
    }

    /* APK 3.8: the colour of the text cursor's handle, as the page last
       asked for it (the secondary colour of its colour scheme). */
    void applyAccent(String hex) {
        if (hex == null) return;
        int res = 0;
        if ("#8A6A1E".equalsIgnoreCase(hex)) res = R.style.AccentW;
        else if ("#A6D0EE".equalsIgnoreCase(hex)) res = R.style.AccentU;
        else if ("#D6D1CA".equalsIgnoreCase(hex)) res = R.style.AccentB;
        else if ("#F4B6A2".equalsIgnoreCase(hex)) res = R.style.AccentR;
        else if ("#B4DAB4".equalsIgnoreCase(hex)) res = R.style.AccentG;
        if (res != 0) getTheme().applyStyle(res, true);
    }

    @Override
    protected void onCreate(Bundle saved) {
        try { applyAccent(Notifier.prefs(this).getString("accent", null)); } catch (Throwable t) { }
        super.onCreate(saved);
        startedAt = SystemClock.uptimeMillis();
        holdSystemSplash();
        // Nothing may outlast this: a cover that never lifts is a dead app.
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() { revealWeb(); }
        }, 12000);

        web = new WebView(this);
        setContentView(web);

        /* The layer that carries the icon until the page is drawn. It hangs on
           the WINDOW, not on the content area: the window background is painted
           across the whole window, while the content area is inset by the status
           and navigation bars, and centring the same bitmap in those two frames
           puts it 15 px apart on this screen. */
        splashCover = new ImageView(this);
        splashCover.setBackgroundColor(0xFF000000);
        splashCover.setImageResource(R.drawable.splash_logo);
        splashCover.setScaleType(ImageView.ScaleType.CENTER);   // never rescale
        splashCover.setClickable(true);                         // swallow taps
        splashCover.setFitsSystemWindows(false);
        try {
            ((ViewGroup) getWindow().getDecorView()).addView(splashCover,
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                           ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (Throwable t) {
            splashCover = null;     // better no cover than a broken screen
        }

        web.setBackgroundColor(0xFF000000);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        CookieManager.getInstance().setAcceptCookie(true);

        web.addJavascriptInterface(new ExportBridge(), "DeckhandExport");
        web.addJavascriptInterface(new NotifyBridge(), "DeckhandNotify");
        scanner = new Scanner(this, web);
        web.addJavascriptInterface(scanner.bridge, "DeckhandScan");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri u = Uri.parse(url);
                String sch = u.getScheme();
                if (("https".equals(sch) || "http".equals(sch)) && HOST.equals(u.getHost())) {
                    return false; // our own site: stay in the app
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) { /* nothing installed for it */ }
                return true;
            }

            /* A page that (re)loads has no scanner screen any more: the camera
               behind it goes, and the WebView is opaque again. */
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                if (scanner != null) scanner.stopUi();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // Not the signal, only a fallback for a page that does not know
                // about appReady(). "Page finished" means the HTML arrived, NOT
                // that the app is on screen, so this waits long enough to lose
                // to the real signal every time.
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override public void run() { releaseWhenDrawn(); }
                }, 5000);
                if (url != null && url.startsWith(START)) {
                    view.evaluateJavascript(EXPORT_HOOK, null);
                }
            }

            @Override
            @SuppressWarnings("deprecation")
            public void onReceivedError(WebView view, int code, String desc, String failingUrl) {
                revealWeb();          // a failure has to be visible too
                if (failingUrl != null && failingUrl.startsWith(START)
                        && (view.getUrl() == null || failingUrl.equals(view.getUrl()))) {
                    loadErrorPage();
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            /* APK 4.2: the card scanner asks for the camera. Android itself
               asks the person once; after that the page simply gets it. */
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        boolean video = false;
                        for (String r : request.getResources())
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) video = true;
                        if (!video) { request.deny(); return; }
                        if (Build.VERSION.SDK_INT < 23
                                || checkSelfPermission("android.permission.CAMERA") == PackageManager.PERMISSION_GRANTED) {
                            request.grant(new String[]{ PermissionRequest.RESOURCE_VIDEO_CAPTURE });
                        } else {
                            if (pendingCam != null) { try { pendingCam.deny(); } catch (Throwable t) { } }
                            pendingCam = request;
                            requestPermissions(new String[]{ "android.permission.CAMERA" }, CAM_REQ);
                        }
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb,
                                             WebChromeClient.FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCb = null;
                    return false;
                }
            }
        });

        /* A blob: download has no URL anything else can open, so it is read out
           in the page and handed to the export bridge. Anything else goes to
           whatever app handles it. */
        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String disp, String mime, long len) {
                if (url != null && url.startsWith("blob:")) {
                    String m = (mime == null) ? "" : mime.replace("'", "");
                    web.evaluateJavascript(
                        "(function(){fetch('" + url.replace("'", "") + "').then(function(r){return r.blob();})" +
                        ".then(function(b){var fr=new FileReader();fr.onload=function(){" +
                        "DeckhandExport.save(String(fr.result).split(',')[1]||'','" + m + "','');};" +
                        "fr.readAsDataURL(b);});})();", null);
                } else if (url != null) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (ActivityNotFoundException e) { }
                }
            }
        });

        String target = urlFromIntent(getIntent());
        if (target != null) {
            web.loadUrl(target);
        } else if (saved != null) {
            web.restoreState(saved);
            if (web.getUrl() == null) web.loadUrl(START);
        } else {
            web.loadUrl(START);
        }
    }

    /* A shared deck link, but only from our own site over https. */
    String urlFromIntent(Intent i) {
        if (i == null || i.getData() == null) return null;
        Uri d = i.getData();
        if (HOST.equals(d.getHost()) && "https".equals(d.getScheme())) return d.toString();
        return null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String target = urlFromIntent(intent);
        if (target != null && web != null) web.loadUrl(target);
    }

    /* Shown when the site itself cannot be reached, in both languages. */
    void loadErrorPage() {
        web.loadDataWithBaseURL(START,
            "<!doctype html><html><body style=\"background:#000;color:#dfe8f2;font-family:sans-serif;display:flex;flex-direction:column;justify-content:flex-end;min-height:92vh;padding:24px;text-align:center;\">"
          + "<div style=\"font-size:40px;\">&#9875;</div>"
          + "<h3 style=\"margin:12px 0 4px;\">Geen verbinding</h3>"
          + "<p style=\"margin:4px 0 16px;color:#9fb3c8;\">Deckhand kon de zee niet op. Controleer je internet en probeer opnieuw.<br>"
          + "<small>No connection &mdash; check your internet and try again.</small></p>"
          + "<button onclick=\"location.replace('" + START + "')\" style=\"padding:14px 20px;font-size:16px;border-radius:12px;border:1px solid #8a1f2d;background:#0d2137;color:#dfe8f2;\">Opnieuw proberen</button>"
          + "</body></html>", "text/html", "utf-8", null);
    }

    class NotifyBridge {
        /* The app calls this the moment its first screen is drawn. Until then
           the launcher splash stays on screen. */
        @JavascriptInterface
        public void appReady() { releaseWhenDrawn(); }

        /* The life counter: while it is open the screen stays on at a fixed
           brightness (APK 3.6: 65% by default, adjustable in the counter's
           settings, or with the phone's own slider). Settings of THIS window
           only -- they end when the counter closes, and Android drops them
           whenever another app is in front. */
        @JavascriptInterface
        public void setTableMode(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    tableOn = on;
                    tableHandedBack = false;
                    watchPhoneSlider(on);
                    applyTableMode();
                }
            });
        }

        /* APK 3.7: 0 = the phone decides, 5..100 = locked at that position
           on the phone's brightness slider. The page remembers the choice. */
        @JavascriptInterface
        public void setTableLevel(final int pct) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    tableLevel = pct <= 0 ? -1f : Math.max(5, Math.min(100, pct)) / 100f;
                    tableHandedBack = false;
                    applyTableMode();
                }
            });
        }

        /* 5..100: a position on the phone's brightness slider. */
        @JavascriptInterface
        public void setTableBrightness(final int pct) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    tableLevel = Math.max(5, Math.min(100, pct)) / 100f;
                    tableHandedBack = false;
                    applyTableMode();
                }
            });
        }

        /* APK 3.8: the page's secondary colour, for the cursor handle. */
        @JavascriptInterface
        public void setAccent(final String hex) {
            try { Notifier.prefs(MainActivity.this).edit().putString("accent", hex).apply(); } catch (Throwable t) { }
            runOnUiThread(new Runnable() {
                @Override public void run() { try { applyAccent(hex); } catch (Throwable t) { } }
            });
        }

        @JavascriptInterface
        public boolean isSupported() { return true; }

        /* APK 4.3: which version of this app is installed ("4.3"). */
        @JavascriptInterface
        public String appVersion() { return versionName(); }

        /* APK 4.3: download the new APK from our own site and open Android's
           installer with it. Only our own host is accepted. */
        @JavascriptInterface
        public void installUpdate(String url) {
            try {
                Uri u = Uri.parse(url);
                if (!"https".equals(u.getScheme()) || !HOST.equals(u.getHost())) return;
                startUpdate(url);
            } catch (Throwable t) { }
        }

        @JavascriptInterface
        public boolean isEnabled() { return Notifier.isEnabled(MainActivity.this); }

        /* Two lanes, switched separately by the page in Extras. An older
           page only calls setEnabled and keeps working. */
        @JavascriptInterface
        public boolean getUpdates() { return Notifier.wantUpdates(MainActivity.this); }

        @JavascriptInterface
        public int getSpoilerEvery() { return Notifier.spoilEvery(MainActivity.this); }

        @JavascriptInterface
        public void setUpdates(boolean on) {
            Notifier.setUpdates(MainActivity.this, on);
            afterTurningOn(on);
        }

        /* APK 4.2: the Wants price alerts, as [{"n": name, "max": 15.0}, ...]. */
        @JavascriptInterface
        public void setPriceWatch(String json) {
            try { Notifier.setPriceWatch(MainActivity.this, json); } catch (Throwable t) { }
            try {
                if (json != null && json.length() > 2) afterTurningOn(true);
            } catch (Throwable t) { }
        }

        /* APK 4.0: the Spoilers page reports the cards it has shown ("set:id,…"). */
        @JavascriptInterface
        public void markSpoilersSeen(final String csv) {
            try { Notifier.markViewed(MainActivity.this, csv); } catch (Throwable t) { }
        }

        @JavascriptInterface
        public void setSpoilerEvery(int every) {
            Notifier.setSpoilEvery(MainActivity.this, every);
            afterTurningOn(every > 0);
        }

        @JavascriptInterface
        public void setLang(String lang) {
            Notifier.prefs(MainActivity.this).edit()
                .putString(Notifier.K_LANG, "nl".equals(lang) ? "nl" : "en").apply();
        }

        /* Android 13 and up will not show a notification until the person says
           yes, so asking is part of switching this on. */
        @JavascriptInterface
        public void setEnabled(boolean on) {
            Notifier.setEnabled(MainActivity.this, on);
            if (on) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (Build.VERSION.SDK_INT >= 33
                                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                                   != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{ "android.permission.POST_NOTIFICATIONS" }, PERM_REQ);
                        }
                    }
                });
                new Thread(new Runnable() {
                    @Override public void run() { Notifier.runCheck(getApplicationContext()); }
                }).start();
            }
        }

        /* Android 13 and up will not show a notification until the person
           says yes, so asking is part of switching anything on. */
        private void afterTurningOn(boolean on) {
            if (!on) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                               != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{ "android.permission.POST_NOTIFICATIONS" }, PERM_REQ);
                    }
                }
            });
            new Thread(new Runnable() {
                @Override public void run() { Notifier.runCheck(getApplicationContext()); }
            }).start();
        }

        @JavascriptInterface
        public boolean permissionGranted() {
            return Build.VERSION.SDK_INT < 33
                || checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                   == PackageManager.PERMISSION_GRANTED;
        }
    }

    /* Releases the held splash. The WebView needs no showing: it has been
       drawing all along, underneath. */
    void revealWeb() {
        webPainted = true;
        hideCover();
    }

    /* Writes an export where a download belongs: the phone's public Downloads
       folder. From Android 10 the only way in is MediaStore, and its Downloads
       collection arrived in API 29 while this APK is built against android.jar
       23 -- hence the reflection. Returns null on failure, and the caller then
       falls back to the share sheet so an export is never lost. */
    Uri saveToDownloads(byte[] data, String name, String mime) {
        String type = (mime == null || mime.length() == 0) ? "application/octet-stream" : mime;
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                Class<?> downloads = Class.forName("android.provider.MediaStore$Downloads");
                Uri collection = (Uri) downloads.getField("EXTERNAL_CONTENT_URI").get(null);
                ContentValues v = new ContentValues();
                v.put("_display_name", name);
                v.put("mime_type", type);
                v.put("relative_path", "Download");
                v.put("is_pending", 1);          // hidden from other apps while we write
                Uri item = getContentResolver().insert(collection, v);
                if (item == null) return null;
                OutputStream os = getContentResolver().openOutputStream(item);
                if (os == null) return null;
                os.write(data);
                os.close();
                ContentValues done = new ContentValues();
                done.put("is_pending", 0);       // now it appears in Files and Downloads
                getContentResolver().update(item, done, null, null);
                return item;
            } catch (Throwable t) { return null; }
        }
        // Android 9 and older: shared storage is still an ordinary folder.
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            dir.mkdirs();
            File f = new File(dir, name);
            FileOutputStream out = new FileOutputStream(f);
            out.write(data);
            out.close();
            return Uri.fromFile(f);
        } catch (Throwable t) { return null; }
    }

    /* A short message to the person, on the UI thread. Used by the Downloads
       export; it sat inside the block that carried the old splash code and was
       swept out with it. */
    void say(final String msg) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show(); }
                catch (Throwable t) { }
            }
        });
    }

    void handOverSplash(final Object view) {
        if (view == null) return;
        final Runnable drop = new Runnable() {
            @Override public void run() {
                try { view.getClass().getMethod("remove").invoke(view); }
                catch (Throwable t) {
                    try { Class.forName("android.window.SplashScreenView")
                            .getMethod("remove").invoke(view); }
                    catch (Throwable t2) { }
                }
            }
        };
        /* The view is ours now. Keep it up until the page has actually been
           drawn, then take it away in one go -- no fade, because underneath is
           the finished app, not another copy of the icon.

           The deadline is not optional: a splash view that is never removed
           leaves the app frozen behind it. */
        final Handler h = new Handler(Looper.getMainLooper());
        final long deadline = SystemClock.uptimeMillis() + SPLASH_HOLD_MS;
        h.post(new Runnable() {
            @Override public void run() {
                if (webPainted || SystemClock.uptimeMillis() > deadline) {
                    drop.run();
                    hideCover();
                } else {
                    h.postDelayed(this, 16);          // look again next frame
                }
            }
        });
    }

    /* Takes our copy of the splash away, once, with no animation -- the page
       underneath is already drawn, so there is nothing to ease into. */
    void hideCover() {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    if (splashCover != null) {
                        ViewGroup parent = (ViewGroup) splashCover.getParent();
                        if (parent != null) parent.removeView(splashCover);
                        splashCover = null;
                    }
                } catch (Throwable t) { }
            }
        });
    }

    /* The honest version. The app telling us its screen is built is not the
       same as that screen being ON the display -- that gap is what kept
       showing as a black flash. postVisualStateCallback answers the real
       question: it fires once the WebView's current contents have actually
       been drawn. Only then does the splash go.

       If anything about it fails we let go immediately, because a splash that
       never leaves is far worse than one that leaves a frame too early. */
    void releaseWhenDrawn() {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (webPainted) return;
                try {
                    web.postVisualStateCallback(1, new WebView.VisualStateCallback() {
                        @Override public void onComplete(long id) { webPainted = true; hideCover(); }
                    });
                } catch (Throwable t) { webPainted = true; hideCover(); }
            }
        });
    }

    class ExportBridge {
        /* APK 4.1: straight to the share sheet, so a backup can go to the
           person's own cloud (Drive, Nextcloud, Dropbox) or their mail. */
        @JavascriptInterface
        public void share(String b64, String mime, String name) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                String safeName = (name == null || name.length() == 0) ? "deckhand-backup.json"
                    : name.replaceAll("[^A-Za-z0-9._-]", "_");
                File dir = new File(getCacheDir(), "exports");
                dir.mkdirs();
                File f = new File(dir, safeName);
                FileOutputStream out = new FileOutputStream(f);
                out.write(data);
                out.close();
                Uri uri = Uri.parse("content://app.deckhand.companion.files/" + Uri.encode(safeName));
                final Intent send = new Intent(Intent.ACTION_SEND);
                send.setType((mime == null || mime.length() == 0) ? "application/octet-stream" : mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_SUBJECT, safeName);
                send.setClipData(ClipData.newRawUri("backup", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            boolean nl = "nl".equals(Locale.getDefault().getLanguage());
                            startActivity(Intent.createChooser(send, nl ? "Back-up bewaren in\u2026" : "Keep the backup in\u2026"));
                        } catch (ActivityNotFoundException e) { }
                    }
                });
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public void save(String b64, String mime, String name) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                String safeName = (name == null) ? "" : name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (safeName.length() == 0) {
                    String ext = "txt";
                    if (mime != null && mime.contains("json")) ext = "json";
                    else if (mime != null && mime.contains("csv")) ext = "csv";
                    safeName = "deckhand-export-" +
                        new SimpleDateFormat("yyyy-MM-dd-HHmmss", Locale.US).format(new Date()) +
                        "." + ext;
                }
                // A download is what was asked for, so try that first.
                if (saveToDownloads(data, safeName, mime) != null) {
                    boolean nl = "nl".equals(Locale.getDefault().getLanguage());
                    say((nl ? "Opgeslagen in Downloads: " : "Saved to Downloads: ") + safeName);
                    return;
                }

                // Only if that failed: hand it to the share sheet instead, so
                // the export still has somewhere to go.
                File dir = new File(getCacheDir(), "exports");
                dir.mkdirs();
                File f = new File(dir, safeName);
                FileOutputStream out = new FileOutputStream(f);
                out.write(data);
                out.close();

                Uri uri = Uri.parse("content://app.deckhand.companion.files/" + Uri.encode(safeName));
                final Intent send = new Intent(Intent.ACTION_SEND);
                send.setType((mime == null || mime.length() == 0) ? "application/octet-stream" : mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.setClipData(ClipData.newRawUri("export", uri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            boolean nl = "nl".equals(Locale.getDefault().getLanguage());
                            startActivity(Intent.createChooser(send,
                                nl ? "Kon niet naar Downloads \u2014 kies waar het heen moet"
                                   : "Could not reach Downloads \u2014 pick a destination"));
                        } catch (ActivityNotFoundException e) { }
                    }
                });
            } catch (Exception e) { }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        if (req == Scanner.PERM_REQ) {
            if (scanner != null) scanner.onPermission(res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED);
            return;
        }
        if (req == CAM_REQ && pendingCam != null) {
            PermissionRequest r = pendingCam;
            pendingCam = null;
            try {
                if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED)
                    r.grant(new String[]{ PermissionRequest.RESOURCE_VIDEO_CAPTURE });
                else r.deny();
            } catch (Throwable t) { }
            return;
        }
        super.onRequestPermissionsResult(req, perms, res);
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        if (req == FILE_REQ) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
                fileCb = null;
            }
            return;
        }
        super.onActivityResult(req, result, data);
    }

    /* The hardware back press.

       It used to lean on the WebView's own history: go back one entry, and
       when there was none left, put the app away. Measured on Stef's phone:
       a single press from any page put the app in the background, because
       the page's history entries are pushed without a user gesture and the
       WebView does not count them -- so canGoBack() was false everywhere and
       the double-press protection never got a chance.

       The page itself knows exactly what a back press should mean: close the
       open sheet, step back a screen, or nothing because we are home. So ask
       it, and only decide here when it says it is standing on the home floor
       -- and then only after a SECOND press within two and a half seconds.
       The wording of the warning lives in the app, in the app's language. */
    private long lastBackAt = 0L;

    @Override
    public void onBackPressed() {
        final WebView w = web;
        if (w == null) { super.onBackPressed(); return; }
        try {
            w.evaluateJavascript(
                "(function(){try{return (window.androidBack?androidBack():0);}catch(e){return 0;}})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String v) {
                        if (v != null && v.indexOf('1') >= 0) { lastBackAt = 0L; return; }
                        long now = SystemClock.elapsedRealtime();
                        if (lastBackAt != 0L && now - lastBackAt < 2500L) { lastBackAt = 0L; moveTaskToBack(true); }
                        else lastBackAt = now;     // the page already showed the warning
                    }
                });
        } catch (Throwable t) {
            if (w.canGoBack()) w.goBack(); else moveTaskToBack(true);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onPause() {
        if (scanner != null) scanner.activityPaused();
        if (web != null) web.onPause();
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        if (scanner != null) scanner.activityResumed();
        // Back from "allow installing from this app": carry on with the update.
        if (pendingUpdate != null && canInstallPackages()) {
            final File f = pendingUpdate;
            pendingUpdate = null;
            launchInstaller(f);
        }
    }

    @Override
    protected void onDestroy() {
        if (scanner != null) scanner.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------- self-update

    File pendingUpdate;
    volatile boolean updating;

    String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Throwable t) { return ""; }
    }

    /* Android 8+ asks once whether this app may install apps. Reflection:
       the APK is built against API 23, where the call does not exist yet. */
    boolean canInstallPackages() {
        if (Build.VERSION.SDK_INT < 26) return true;
        try { return (Boolean) getPackageManager().getClass().getMethod("canRequestPackageInstalls").invoke(getPackageManager()); }
        catch (Throwable t) { return true; }
    }

    void tellPage(final String js) {
        runOnUiThread(new Runnable() {
            @Override public void run() { try { if (web != null) web.evaluateJavascript(js, null); } catch (Throwable t) { } }
        });
    }

    void startUpdate(final String url) {
        if (updating) return;
        updating = true;
        final boolean nl = "nl".equals(Notifier.prefs(this).getString(Notifier.K_LANG, "en"));
        say(nl ? "Nieuwe versie downloaden\u2026" : "Downloading the new version\u2026");
        tellPage("window.dhUpdateState&&dhUpdateState('downloading')");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    byte[] data = Notifier.fetchBytes(url);
                    if (data == null || data.length < 50000 || data[0] != 'P' || data[1] != 'K') throw new Exception("not an apk");
                    File dir = new File(getCacheDir(), "exports");
                    dir.mkdirs();
                    File f = new File(dir, "Deckhand-update.apk");
                    FileOutputStream out = new FileOutputStream(f);
                    out.write(data);
                    out.close();
                    updating = false;
                    if (canInstallPackages()) launchInstaller(f);
                    else {
                        pendingUpdate = f;
                        tellPage("window.dhUpdateState&&dhUpdateState('permission')");
                        say(nl ? "Sta toe dat Deckhand apps installeert, en ga dan terug." : "Allow Deckhand to install apps, then come back.");
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                try {
                                    startActivity(new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES",
                                        Uri.parse("package:" + getPackageName())));
                                } catch (Throwable t) { launchInstaller(pendingUpdate); pendingUpdate = null; }
                            }
                        });
                    }
                } catch (Throwable t) {
                    updating = false;
                    tellPage("window.dhUpdateState&&dhUpdateState('error')");
                    say(nl ? "Downloaden mislukt \u2014 probeer het later nog eens." : "Download failed \u2014 try again later.");
                }
            }
        }).start();
    }

    void launchInstaller(final File f) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    Uri uri = Uri.parse("content://app.deckhand.companion.files/" + Uri.encode(f.getName()));
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(uri, "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    tellPage("window.dhUpdateState&&dhUpdateState('installing')");
                } catch (Throwable t) {
                    tellPage("window.dhUpdateState&&dhUpdateState('error')");
                }
            }
        });
    }
}
