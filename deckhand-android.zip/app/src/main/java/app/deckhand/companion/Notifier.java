package app.deckhand.companion;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/* The Android WebView has no Push API, so a page inside the Deckhand app can
   never receive a web push. Instead the app watches, on the device itself,
   for the same three things the server-side check watches for:

     1. a new Deckhand version  -> version.json on the site
     2. a newly announced set   -> Scryfall's /sets catalogue
     3. newly spoiled cards     -> the upcoming sets on Scryfall

   Two lanes, switched separately in Extras: app updates, and spoilers at the
   pace you picked (every card, every 5, every 10, or never). Nothing is
   posted outside 09:00-21:00 local time.

   No Google services, no push server, nothing to sign up for. */
public class Notifier {

    static final String PREFS = "deckhand_notify";
    static final String K_ON = "enabled";          // master: either lane on
    static final String K_UPDATES = "wantUpdates";
    static final String K_SPOIL_EVERY = "spoilEvery";
    static final String K_LANG = "lang";
    static final String K_VERSION = "lastVersion";
    static final String K_SEEN_SETS = "announcedSets";
    static final String K_SEEN_CARDS = "seenCards";
    static final String K_PENDING = "pendingCards";
    static final String K_PENDING_NAMES = "pendingNames";
    /* Since 3.9: seen cards are stored as "set:id", and every set that is
       being watched is listed here. A set that is not on this list yet is
       read once in silence -- whatever it already holds is old news. */
    static final String K_SPOIL_WATCH = "spoilWatch";
    static final String K_SEEN_CARDS2 = "seenCards2";
    /* A card that was previewed longer ago than this is not news. */
    static final int FRESH_DAYS = 3;
    /* Since 4.0: what the person has SEEN in the app ("set:id", reported by
       the Spoilers page), what is new and still unseen ("set:id\u0002name
       \u0002date"), and which of those were already announced once. */
    static final String K_VIEWED = "spoilViewed";
    static final String K_UNSEEN = "spoilUnseen";
    static final String K_ANNOUNCED = "spoilAnnounced";
    /* Since 4.2: the Wants price alerts, the cards already announced as
       under their limit (until they climb back over it), and the day the
       price file was last read. */
    static final String K_PRICE_WATCH = "priceWatch";
    static final String K_PRICE_TOLD = "priceTold";
    static final String K_PRICE_DAY = "priceDay";
    static final String CHANNEL = "deckhand-news";
    static final String SITE = "https://deckhandcompanion.netlify.app";
    static final int REQ_ALARM = 4711;
    static final int WINDOW_FROM = 9, WINDOW_TO = 21;
    /* Sets to watch for spoilers, and pages per set: a phone on mobile data
       should not page through an entire catalogue every three hours. */
    static final int MAX_SPOIL_SETS = 4, MAX_SPOIL_PAGES = 2;

    /* Sets worth telling someone about; the rest are tokens, memorabilia and
       minigame sheets. Mirrors the server-side list. */
    static final Set<String> KINDS = new HashSet<String>();
    static {
        KINDS.add("expansion"); KINDS.add("commander"); KINDS.add("masters");
        KINDS.add("draft_innovation"); KINDS.add("core");
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /* The master switch stays what it always was: on when either lane is on.
       A device upgrading from 3.2 has only that one, so both lanes inherit
       it -- exactly what it used to mean. */
    static boolean isEnabled(Context c) { return prefs(c).getBoolean(K_ON, false); }
    static boolean isDutch(Context c)   { return "nl".equals(prefs(c).getString(K_LANG, "en")); }

    static boolean wantUpdates(Context c) {
        SharedPreferences p = prefs(c);
        return p.contains(K_UPDATES) ? p.getBoolean(K_UPDATES, false) : p.getBoolean(K_ON, false);
    }
    static int spoilEvery(Context c) {
        SharedPreferences p = prefs(c);
        if (p.contains(K_SPOIL_EVERY)) {
            int v = p.getInt(K_SPOIL_EVERY, 5);
            return (v == 0 || v == 1 || v == 5 || v == 10) ? v : 5;
        }
        return p.getBoolean(K_ON, false) ? 5 : 0;   // upgraded from the single switch
    }
    static void setUpdates(Context c, boolean on) {
        prefs(c).edit().putBoolean(K_UPDATES, on).apply();
        syncMaster(c);
    }
    static void setSpoilEvery(Context c, int every) {
        int v = (every == 0 || every == 1 || every == 5 || every == 10) ? every : 5;
        prefs(c).edit().putInt(K_SPOIL_EVERY, v).apply();
        syncMaster(c);
    }
    /* The master follows the two lanes, and the alarm follows the master. */
    static void syncMaster(Context c) {
        boolean on = wantUpdates(c) || spoilEvery(c) > 0 || hasPriceWatch(c);
        prefs(c).edit().putBoolean(K_ON, on).apply();
        if (on) scheduleDaily(c); else cancelDaily(c);
    }

    /* Nothing at night. The alarm fires every few hours; outside the window
       the check simply does nothing, so an evening release is announced the
       next morning. */
    static boolean insideWindow() {
        int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        return h >= WINDOW_FROM && h < WINDOW_TO;
    }

    // ---------------------------------------------------------------- alarm

    static PendingIntent alarmIntent(Context c) {
        Intent i = new Intent(c, NotifyReceiver.class).setAction(NotifyReceiver.ACTION_CHECK);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, REQ_ALARM, i, flags);
    }

    /* Inexact on purpose: Android may batch it with other wake-ups to save
       battery. Every three hours rather than daily now -- spoiler season
       moves within a day, and the 09:00-21:00 window trims it to four or
       five real checks. */
    static void scheduleDaily(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long first = System.currentTimeMillis() + 30L * 60L * 1000L;   // first look in half an hour
        am.setInexactRepeating(AlarmManager.RTC, first, 3L * AlarmManager.INTERVAL_HOUR, alarmIntent(c));
    }

    static void cancelDaily(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(alarmIntent(c));
    }

    /* Kept for an older page inside a newer shell: one switch for both lanes. */
    static void setEnabled(Context c, boolean on) {
        prefs(c).edit()
            .putBoolean(K_ON, on)
            .putBoolean(K_UPDATES, on)
            .putInt(K_SPOIL_EVERY, on ? 5 : 0)
            .apply();
        if (on) scheduleDaily(c); else cancelDaily(c);
    }

    // ------------------------------------------------------------ the check

    static String fetch(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(20000);
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("User-Agent", "Deckhand-Android/1.1");
        try {
            if (con.getResponseCode() / 100 != 2) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } finally {
            con.disconnect();
        }
    }

    /* Runs on a background thread. The parts are independent: a broken
       Scryfall must not cost you the update notice, and the other way round. */
    static void runCheck(Context c) {
        if (!isEnabled(c)) return;
        if (!insideWindow()) return;
        if (wantUpdates(c)) checkVersion(c);
        if (spoilEvery(c) > 0) checkSpoilers(c);   // a new SET is no spoiler: no push for that
        if (hasPriceWatch(c)) checkPrices(c);
    }

    // ------------------------------------------------------- price alerts

    static boolean hasPriceWatch(Context c) {
        String s = prefs(c).getString(K_PRICE_WATCH, "");
        return s.length() > 2;
    }
    static void setPriceWatch(Context c, String json) {
        prefs(c).edit().putString(K_PRICE_WATCH, json == null ? "" : json).remove(K_PRICE_DAY).apply();
        syncMaster(c);
    }

    static byte[] fetchBytes(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(30000);
        con.setRequestProperty("User-Agent", "Deckhand-Android/4.4");
        try {
            if (con.getResponseCode() / 100 != 2) return null;
            InputStream in = con.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int k;
            while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
            in.close();
            return out.toByteArray();
        } finally {
            con.disconnect();
        }
    }

    /* Once a day: the site's daily price file (the cheapest paper printing
       of every card, ~300 KB) against the watched cards. One notification
       for everything that dropped under its limit; a card is told once,
       until it climbs back over. */
    static synchronized void checkPrices(Context c) {
        try {
            SharedPreferences p = prefs(c);
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            if (today.equals(p.getString(K_PRICE_DAY, ""))) return;
            JSONArray watch = new JSONArray(p.getString(K_PRICE_WATCH, "[]"));
            if (watch.length() == 0) return;
            Map<String, Double> max = new HashMap<String, Double>();
            Map<String, String> real = new HashMap<String, String>();
            for (int i = 0; i < watch.length(); i++) {
                JSONObject o = watch.optJSONObject(i);
                if (o == null) continue;
                String nm = o.optString("n", "");
                double mx = o.optDouble("max", -1);
                if (nm.length() == 0 || !(mx > 0)) continue;
                max.put(nm.toLowerCase(Locale.ROOT), mx);
                real.put(nm.toLowerCase(Locale.ROOT), nm);
            }
            byte[] raw = fetchBytes(SITE + "/prices-slim.tsv.gz?t=" + System.currentTimeMillis());
            if (raw == null || raw.length < 100) return;
            InputStream in = new ByteArrayInputStream(raw);
            if ((raw[0] & 0xff) == 0x1f && (raw[1] & 0xff) == 0x8b) in = new GZIPInputStream(in);
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            Map<String, Double> now = new HashMap<String, Double>();
            String line;
            int rows = 0;
            while ((line = r.readLine()) != null) {
                rows++;
                int t = line.indexOf('\t');
                if (t < 1) continue;
                String key = line.substring(0, t).toLowerCase(Locale.ROOT);
                if (!max.containsKey(key)) continue;
                try { now.put(key, Double.parseDouble(line.substring(t + 1).trim())); } catch (Exception e) { }
            }
            r.close();
            if (rows < 1000) return;                       // a thin file is a broken file
            p.edit().putString(K_PRICE_DAY, today).apply();

            Set<String> told = new HashSet<String>(p.getStringSet(K_PRICE_TOLD, new HashSet<String>()));
            boolean nl = isDutch(c);
            StringBuilder text = new StringBuilder();
            int hits = 0;
            for (String key : max.keySet()) {
                Double v = now.get(key);
                if (v == null) continue;
                if (v <= max.get(key)) {
                    if (told.contains(key)) continue;
                    told.add(key);
                    hits++;
                    if (hits <= 4) {
                        if (text.length() > 0) text.append('\n');
                        text.append(real.get(key)).append(": ").append(eur(v, nl))
                            .append(nl ? " (grens " : " (limit ").append(eur(max.get(key), nl)).append(')');
                    }
                } else {
                    told.remove(key);                      // back over: may be told again
                }
            }
            told.retainAll(max.keySet());
            p.edit().putStringSet(K_PRICE_TOLD, told).apply();
            if (hits == 0) return;
            if (hits > 4) text.append(nl ? ("\nen nog " + (hits - 4)) : ("\nand " + (hits - 4) + " more"));
            String title = hits == 1
                ? (nl ? "💰 Gezochte kaart onder je grens" : "💰 A wanted card is under your limit")
                : (nl ? "💰 " + hits + " gezochte kaarten onder je grens" : "💰 " + hits + " wanted cards under your limit");
            notify(c, 5, title, text.toString(), "/?go=wants");
        } catch (Exception e) { /* try again at the next check */ }
    }

    static String eur(double v, boolean nl) {
        String s = String.format(Locale.US, "%.2f", v);
        return "\u20AC" + (nl ? s.replace('.', ',') : s);
    }

    static void checkVersion(Context c) {
        try {
            String body = fetch(SITE + "/version.json?t=" + System.currentTimeMillis());
            if (body == null) return;
            JSONObject j = new JSONObject(body);
            String v = j.optString("version", "");
            if (v.length() == 0) return;

            SharedPreferences p = prefs(c);
            String seen = p.getString(K_VERSION, "");
            // First run only records where we are -- nobody wants a notification
            // announcing the version they already have.
            if (seen.length() == 0) { p.edit().putString(K_VERSION, v).apply(); return; }
            if (seen.equals(v)) return;
            p.edit().putString(K_VERSION, v).apply();

            boolean nl = isDutch(c);
            JSONObject notes = j.optJSONObject("notes");
            JSONArray list = notes == null ? null : notes.optJSONArray(nl ? "nl" : "en");
            StringBuilder body2 = new StringBuilder();
            if (list != null) {
                for (int i = 0; i < list.length() && i < 3; i++) {
                    if (body2.length() > 0) body2.append('\n');
                    body2.append("• ").append(list.optString(i, ""));
                }
            }
            if (body2.length() == 0) {
                body2.append(nl ? "Open de app om te zien wat er nieuw is."
                                : "Open the app to see what changed.");
            }
            notify(c, 1, "Deckhand Update — v" + v, body2.toString(), "/?go=changelog");
        } catch (Exception e) { /* try again tomorrow */ }
    }

    static void checkSets(Context c) {
        try {
            String body = fetch("https://api.scryfall.com/sets");
            if (body == null) return;
            JSONArray data = new JSONObject(body).optJSONArray("data");
            if (data == null) return;

            SharedPreferences p = prefs(c);
            Set<String> seen = new HashSet<String>(p.getStringSet(K_SEEN_SETS, new HashSet<String>()));
            boolean first = seen.isEmpty();

            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            long now = System.currentTimeMillis();
            String from = f.format(new Date(now));   // already out = no spoilers to see
            String to   = f.format(new Date(now + 45L * 86400000L));

            String freshName = null;
            int freshCount = 0;
            Set<String> keep = new HashSet<String>();

            for (int i = 0; i < data.length(); i++) {
                JSONObject s = data.optJSONObject(i);
                if (s == null) continue;
                if (s.optBoolean("digital", false)) continue;
                if (!KINDS.contains(s.optString("set_type", ""))) continue;
                String rel = s.optString("released_at", "");
                if (rel.length() == 0 || rel.compareTo(from) <= 0 || rel.compareTo(to) > 0) continue;
                String code = s.optString("code", "");
                if (code.length() == 0) continue;
                keep.add(code);
                if (!seen.contains(code)) { freshCount++; if (freshName == null) freshName = s.optString("name", code); }
            }

            // Keep only what is still inside the window, so the list cannot grow forever.
            seen.addAll(keep);
            seen.retainAll(keep);
            p.edit().putStringSet(K_SEEN_SETS, seen).apply();

            if (first || freshCount == 0) return;   // first run seeds quietly
            boolean nl = isDutch(c);
            String title = nl ? "🔮 Nieuwe Magic-set gespot" : "🔮 A new Magic set is up";
            String text = freshCount == 1
                ? (nl ? freshName + " staat op Scryfall — bekijk de spoilers."
                      : freshName + " just appeared on Scryfall — go see the spoilers.")
                : (nl ? freshCount + " nieuwe sets gespot, waaronder " + freshName + "."
                      : freshCount + " new sets spotted, including " + freshName + ".");
            notify(c, 2, title, text, "/?go=spoilers");
        } catch (Exception e) { /* try again tomorrow */ }
    }

    /* Newly spoiled cards.

       Why 3.8 once announced 263 old cards: the list of seen cards was
       replaced by whatever the last check managed to download. A set that
       was new to the list (or had dropped off it for a while, or whose
       download failed once) then counted ALL its cards as new.

       Now:
         - a set seen for the first time is read in silence;
         - a failed download keeps what was already known;
         - a card previewed more than FRESH_DAYS ago is never news;
         - the push names only the newest cards, as many as you picked in
           Extras (1, 5 or 10). */
    /* The Spoilers page reports what it has shown you. Those cards are seen:
       they never count toward a push, and once nothing unseen is left the
       spoiler push in the tray goes away by itself. */
    static synchronized void markViewed(Context c, String csv) {
        if (csv == null || csv.length() == 0) return;
        SharedPreferences p = prefs(c);
        Set<String> viewed = new HashSet<String>(p.getStringSet(K_VIEWED, new HashSet<String>()));
        for (String k : csv.split(",")) { k = k.trim(); if (k.indexOf(':') > 0) viewed.add(k); }
        Set<String> unseen = new HashSet<String>();
        for (String e : p.getStringSet(K_UNSEEN, new HashSet<String>())) {
            String key = e.split("\u0002")[0];
            if (!viewed.contains(key)) unseen.add(e);
        }
        p.edit().putStringSet(K_VIEWED, viewed).putStringSet(K_UNSEEN, unseen).apply();
        if (unseen.isEmpty()) {
            try {
                NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(3);
            } catch (Exception e) { }
        }
    }

    /* Newly spoiled cards you have not seen yet.
         - the checker remembers every card it has met ("set:id"), so only
           cards NEW on Scryfall since the last look can count;
         - a set met for the first time only counts cards with a fresh
           preview date (a whole set appearing at once is not news);
         - reprints and cards previewed more than FRESH_DAYS ago never count;
         - cards the app has already shown you never count;
         - each card is announced once, and the push fires when as many
           unannounced ones are waiting as you picked in Extras (1, 5, 10),
           naming the newest. */
    static synchronized void checkSpoilers(Context c) {
        try {
            int every = spoilEvery(c);
            if (every <= 0) return;

            String body = fetch("https://api.scryfall.com/sets");
            if (body == null) return;
            JSONArray data = new JSONObject(body).optJSONArray("data");
            if (data == null) return;

            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            String today = f.format(new Date());
            String freshFrom = f.format(new Date(System.currentTimeMillis() - FRESH_DAYS * 86400000L));

            java.util.List<JSONObject> up = new java.util.ArrayList<JSONObject>();
            for (int i = 0; i < data.length(); i++) {
                JSONObject st = data.optJSONObject(i);
                if (st == null || st.optBoolean("digital", false)) continue;
                if (!KINDS.contains(st.optString("set_type", ""))) continue;
                String rel = st.optString("released_at", "");
                if (rel.length() == 0 || rel.compareTo(today) <= 0) continue;   // already out
                if (st.optString("code", "").length() == 0) continue;
                up.add(st);
            }
            java.util.Collections.sort(up, new java.util.Comparator<JSONObject>() {
                public int compare(JSONObject x, JSONObject y) {
                    return x.optString("released_at", "").compareTo(y.optString("released_at", ""));
                }
            });
            java.util.List<String> codes = new java.util.ArrayList<String>();
            for (int i = 0; i < up.size() && codes.size() < MAX_SPOIL_SETS; i++) codes.add(up.get(i).optString("code"));
            Set<String> inWindow = new HashSet<String>(codes);

            SharedPreferences p = prefs(c);
            Set<String> watch = new HashSet<String>(p.getStringSet(K_SPOIL_WATCH, new HashSet<String>()));
            Set<String> seen = new HashSet<String>(p.getStringSet(K_SEEN_CARDS2, new HashSet<String>()));
            Set<String> viewed = new HashSet<String>(p.getStringSet(K_VIEWED, new HashSet<String>()));
            Set<String> announced = new HashSet<String>(p.getStringSet(K_ANNOUNCED, new HashSet<String>()));
            java.util.Map<String, String> unseen = new java.util.HashMap<String, String>();
            for (String e : p.getStringSet(K_UNSEEN, new HashSet<String>())) unseen.put(e.split("\u0002")[0], e);

            Set<String> keepSeen = new HashSet<String>();
            Set<String> keepWatch = new HashSet<String>();

            for (String code : codes) {
                String pre = code + ":";
                for (String e : seen) if (e.startsWith(pre)) keepSeen.add(e);   // never forget on a failed fetch
                boolean firstLook = !watch.contains(code);
                boolean fetched = false;
                String url = "https://api.scryfall.com/cards/search?unique=cards&order=spoiled&q="
                           + java.net.URLEncoder.encode("set:" + code, "UTF-8");
                for (int page = 0; page < MAX_SPOIL_PAGES && url != null; page++) {
                    String raw = fetch(url);
                    if (raw == null) break;
                    JSONObject j = new JSONObject(raw);
                    JSONArray cards = j.optJSONArray("data");
                    if (cards == null) break;
                    fetched = true;
                    for (int i = 0; i < cards.length(); i++) {
                        JSONObject card = cards.optJSONObject(i);
                        if (card == null) continue;
                        String id = card.optString("id", "");
                        if (id.length() == 0) continue;
                        String key = pre + id;
                        if (keepSeen.contains(key)) continue;
                        keepSeen.add(key);
                        if (card.optBoolean("reprint", false)) continue;   // a reprint is no spoiler
                        String layout = card.optString("layout", "");
                        if ("token".equals(layout) || "double_faced_token".equals(layout) || "art_series".equals(layout) || "emblem".equals(layout)) continue;
                        JSONObject pv = card.optJSONObject("preview");
                        String when = pv == null ? "" : pv.optString("previewed_at", "");
                        if (when.length() > 0 && when.compareTo(freshFrom) < 0) continue;   // old news
                        if (firstLook && when.length() == 0) continue;   // a whole new set is not news
                        if (viewed.contains(key)) continue;              // already seen in the app
                        unseen.put(key, key + "\u0002" + card.optString("name", "") + "\u0002" + (when.length() > 0 ? when : today) + "\u0002" + cardImage(card));
                    }
                    url = j.optBoolean("has_more", false) ? j.optString("next_page", null) : null;
                }
                if (fetched || !firstLook) keepWatch.add(code);
            }
            // Only sets still in spoiler season are remembered.
            Set<String> keepUnseen = new HashSet<String>(), keepViewed = new HashSet<String>(), keepAnn = new HashSet<String>();
            for (java.util.Map.Entry<String, String> e : unseen.entrySet()) {
                String code = e.getKey().split(":")[0];
                if (inWindow.contains(code) && !viewed.contains(e.getKey())) keepUnseen.add(e.getValue());
            }
            for (String k : viewed) if (inWindow.contains(k.split(":")[0])) keepViewed.add(k);
            for (String k : announced) if (inWindow.contains(k.split(":")[0])) keepAnn.add(k);
            p.edit().putStringSet(K_SEEN_CARDS2, keepSeen).putStringSet(K_SPOIL_WATCH, keepWatch)
                .putStringSet(K_UNSEEN, keepUnseen).putStringSet(K_VIEWED, keepViewed).putStringSet(K_ANNOUNCED, keepAnn)
                .remove(K_SEEN_CARDS).remove(K_PENDING).remove(K_PENDING_NAMES).apply();

            // Unseen and not announced yet, newest first.
            java.util.List<String[]> fresh = new java.util.ArrayList<String[]>();
            for (String e : keepUnseen) {
                String[] parts = e.split("\u0002");
                if (parts.length < 3 || keepAnn.contains(parts[0])) continue;
                fresh.add(parts);
            }
            if (fresh.size() < every) return;   // not enough yet: wait for more
            java.util.Collections.sort(fresh, new java.util.Comparator<String[]>() {
                public int compare(String[] x, String[] y) { return y[2].compareTo(x[2]); }
            });
            // Named in the text: as many as you picked, and never fewer than
            // the cards in the picture -- three spoiled at once are three.
            int nameMax = Math.max(every, Math.min(PIC_MAX, fresh.size()));
            java.util.LinkedHashSet<String> names = new java.util.LinkedHashSet<String>();
            for (String[] v : fresh) { if (names.size() >= nameMax) break; if (v[1].length() > 0) names.add(v[1]); }
            for (String[] v : fresh) keepAnn.add(v[0]);
            p.edit().putStringSet(K_ANNOUNCED, keepAnn).apply();
            // The newest cards, as pictures (a card without one is skipped).
            java.util.List<String> pics = new java.util.ArrayList<String>();
            for (String[] v : fresh) { if (pics.size() >= PIC_MAX) break; if (v.length > 3 && v[3].startsWith("https://")) pics.add(v[3]); }

            boolean nl = isDutch(c);
            StringBuilder tekst = new StringBuilder();
            for (String n : names) { if (tekst.length() > 0) tekst.append(", "); tekst.append(n); }
            int rest = fresh.size() - names.size();
            if (rest > 0) tekst.append(nl ? (" en nog " + rest) : (" and " + rest + " more"));
            tekst.append(nl ? " — open Deckhand om ze te bekijken."
                            : " — open Deckhand to see them.");
            int n = fresh.size();
            String kop = n == 1
                ? (nl ? "🔮 Nieuwe kaart gespoild" : "🔮 A new card was spoiled")
                : (nl ? "🔮 " + n + " nieuwe spoilers" : "🔮 " + n + " new spoilers");
            // One card: the tap opens that card. More: the Spoilers page.
            String path = "/?go=spoilers";
            if (n == 1 && fresh.get(0)[1].length() > 0) path = "/?card=" + Uri.encode(fresh.get(0)[1]);
            if (!notifyCards(c, 3, kop, tekst.toString(), path, pics)) notify(c, 3, kop, tekst.toString(), path);
        } catch (Exception e) { /* try again in a few hours */ }
    }

    // --------------------------------------------------------- notification

    /* Notification channels arrived in API 26, and the only Android platform
       jar available to this build is 23 — so the newer calls go through
       reflection rather than being named at compile time. They are guarded by
       the same SDK_INT check either way. */
    static final int IMPORTANCE_DEFAULT = 3;

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            boolean nl = isDutch(c);
            Class<?> chCls = Class.forName("android.app.NotificationChannel");
            Object ch = chCls.getConstructor(String.class, CharSequence.class, int.class)
                .newInstance(CHANNEL,
                    nl ? "Nieuws & updates" : "News & updates",
                    IMPORTANCE_DEFAULT);
            chCls.getMethod("setDescription", String.class)
                .invoke(ch, nl ? "Nieuwe sets en Deckhand-updates." : "New sets and Deckhand updates.");
            NotificationManager.class.getMethod("createNotificationChannel", chCls).invoke(nm, ch);
        } catch (Throwable t) { /* the pre-26 path still posts fine */ }
    }

    static Notification.Builder builder(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                return Notification.Builder.class
                    .getConstructor(Context.class, String.class)
                    .newInstance(c, CHANNEL);
            } catch (Throwable t) { /* fall through */ }
        }
        return new Notification.Builder(c);
    }

    // ----------------------------------------------------- card pictures

    /* At most this many cards in one picture: three cards side by side are
       almost exactly the 2:1 strip Android shows. */
    static final int PIC_MAX = 3;
    /* The strip: 2:1, small enough to travel to the system in one piece
       (a notification picture is copied across processes). */
    static final int STRIP_W = 900, STRIP_H = 450;

    /* The card's "normal" image (488 x 680), the front face for a two-faced
       card. Empty when Scryfall has none yet. */
    static String cardImage(JSONObject card) {
        JSONObject iu = card.optJSONObject("image_uris");
        if (iu == null) {
            JSONArray faces = card.optJSONArray("card_faces");
            JSONObject f0 = faces == null ? null : faces.optJSONObject(0);
            iu = f0 == null ? null : f0.optJSONObject("image_uris");
        }
        String u = iu == null ? "" : iu.optString("normal", "");
        return u.replace("\u0002", "");
    }

    static Bitmap loadCard(String url) {
        try {
            byte[] raw = fetchBytes(url);
            if (raw == null || raw.length == 0) return null;
            return BitmapFactory.decodeByteArray(raw, 0, raw.length);
        } catch (Throwable t) { return null; }
    }

    /* The cards side by side, each at its own shape (63:88), as tall as the
       strip allows and centred. Corners rounded like a real card. Everything
       around them stays transparent, so the notification's own background
       shows through: a single card stands in the middle with room left and
       right, never stretched. */
    static Bitmap cardStrip(java.util.List<Bitmap> cards) {
        int n = cards.size();
        if (n == 0) return null;
        Bitmap out = Bitmap.createBitmap(STRIP_W, STRIP_H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        float pad = STRIP_H * 0.04f, gap = STRIP_W * 0.025f;
        float h = STRIP_H - 2 * pad;
        float w = h * 63f / 88f;
        float room = STRIP_W - 2 * pad - (n - 1) * gap;
        if (n * w > room) { w = room / n; h = w * 88f / 63f; }
        float x = (STRIP_W - (n * w + (n - 1) * gap)) / 2f, y = (STRIP_H - h) / 2f;
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        for (Bitmap b : cards) {
            RectF dst = new RectF(x, y, x + w, y + h);
            Path clip = new Path();
            float r = w * 0.045f;
            clip.addRoundRect(dst, r, r, Path.Direction.CW);
            cv.save();
            cv.clipPath(clip);
            cv.drawBitmap(b, null, dst, paint);
            cv.restore();
            x += w + gap;
        }
        return out;
    }

    /* The small square beside the collapsed notification: the first card's
       art. */
    static Bitmap artSquare(Bitmap card) {
        try {
            int w = card.getWidth(), hh = card.getHeight();
            int side = Math.round(w * 0.78f);
            int left = Math.round(w * 0.11f), top = Math.round(hh * 0.115f);
            if (top + side > hh) side = hh - top;
            Bitmap out = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888);
            new Canvas(out).drawBitmap(card, new Rect(left, top, left + side, top + side), new Rect(0, 0, 192, 192),
                new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
            return out;
        } catch (Throwable t) { return null; }
    }

    /* The spoiler push with its picture. False when no picture could be
       made (offline images, an odd card): the caller then posts the plain
       text notification, so a push is never lost over a picture. */
    static boolean notifyCards(Context c, int id, String title, String text, String path, java.util.List<String> urls) {
        try {
            if (urls == null || urls.isEmpty()) return false;
            java.util.List<Bitmap> cards = new java.util.ArrayList<Bitmap>();
            for (String u : urls) { Bitmap b = loadCard(u); if (b != null) cards.add(b); }
            if (cards.isEmpty()) return false;
            Bitmap strip = cardStrip(cards);
            if (strip == null) return false;
            Bitmap thumb = artSquare(cards.get(0));

            ensureChannel(c);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return false;
            Intent open = new Intent(c, MainActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse(SITE + path))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getActivity(c, id, open, flags);

            Notification.BigPictureStyle style = new Notification.BigPictureStyle()
                .bigPicture(strip)
                .setSummaryText(text);
            if (thumb != null) style.bigLargeIcon((Bitmap) null);   // opened: the strip, not the square too
            Notification.Builder b = builder(c);
            b.setSmallIcon(R.drawable.ic_stat_deckhand)
             .setContentTitle(title)
             .setContentText(text)
             .setStyle(style)
             .setAutoCancel(true)
             .setContentIntent(pi);
            if (thumb != null) b.setLargeIcon(thumb);
            nm.notify(id, b.build());
            return true;
        } catch (Throwable t) { return false; }
    }

    static void notify(Context c, int id, String title, String text, String path) {
        try {
            ensureChannel(c);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            Intent open = new Intent(c, MainActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse(SITE + path))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getActivity(c, id, open, flags);

            Notification.Builder b = builder(c);
            b.setSmallIcon(R.drawable.ic_stat_deckhand)
             .setContentTitle(title)
             .setContentText(text)
             .setStyle(new Notification.BigTextStyle().bigText(text))
             .setAutoCancel(true)
             .setContentIntent(pi);
            nm.notify(id, b.build());
        } catch (Exception e) { }
    }
}
