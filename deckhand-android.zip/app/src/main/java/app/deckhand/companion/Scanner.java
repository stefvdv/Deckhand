package app.deckhand.companion;

import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Point;
import android.media.Image;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Size;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.core.resolutionselector.AspectRatioStrategy;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.resolutionselector.ResolutionStrategy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/* APK 5.0: the card scanner's camera and text reading, native.

   The page keeps its whole scanner screen (list, buttons, the green outline,
   the matching of names and printings). Only two things move into the app:

   - The CAMERA. A CameraX preview sits BEHIND the WebView, exactly under the
     page's camera box; while scanning the WebView is transparent and the page
     leaves a hole there. Android's own camera path: correct colours (the
     WebView camera swapped them on Stef's phone), real autofocus, the lamp.
   - The READING. Every frame goes through Google's ML Kit text recognition
     (model inside the app, no Play Services needed). What it read -- every
     line and word with its corners -- plus a 240 px grey copy of the frame
     (for the page's edge finder and art fingerprint) is handed to the page.

   Page -> app (window.DeckhandScan): start(rect), place(rect), stop(),
   next(), torch(on), focus(fx, fy).
   App -> page: window.dhScanNative(kind, data) with kind 'ready' {torch},
   'frame' {...}, 'denied', 'error'.

   Flow control: the page calls next() when it has finished a frame. At most
   one frame waits in the meantime (the newest), so the page is never
   flooded and never waits long. */
final class Scanner implements LifecycleOwner {

    static final int PERM_REQ = 74;
    static final int THUMB_W = 240;

    final MainActivity act;
    final WebView web;
    final LifecycleRegistry life;
    final Handler ui = new Handler(Looper.getMainLooper());
    final ExecutorService worker = Executors.newSingleThreadExecutor();
    final Executor uiExec = new Executor() {
        @Override public void execute(Runnable r) { ui.post(r); }
    };
    final Bridge bridge = new Bridge();

    PreviewView view;
    ProcessCameraProvider provider;
    Camera camera;
    TextRecognizer rec;

    boolean on = false;              // the page wants the camera (UI thread)
    boolean actResumed = true;       // the activity is in front (UI thread)
    volatile boolean running = false;
    int rx, ry, rw, rh;              // the camera box, in screen pixels

    final Object flow = new Object();
    boolean pageReady = true;        // guarded by flow
    String waiting = null;           // guarded by flow

    Scanner(MainActivity a, WebView w) {
        act = a;
        web = w;
        life = new LifecycleRegistry(this);
        life.setCurrentState(Lifecycle.State.CREATED);
    }

    @NonNull
    @Override
    public Lifecycle getLifecycle() { return life; }

    // ---------------------------------------------------------- the bridge

    final class Bridge {
        @JavascriptInterface
        public String version() { return "1"; }

        @JavascriptInterface
        public void start(final String rect) {
            ui.post(new Runnable() { @Override public void run() { startUi(rect); } });
        }

        @JavascriptInterface
        public void place(final String rect) {
            ui.post(new Runnable() { @Override public void run() { placeUi(rect); } });
        }

        @JavascriptInterface
        public void stop() {
            ui.post(new Runnable() { @Override public void run() { stopUi(); } });
        }

        /* The page finished the last frame: hand over the one waiting, if any. */
        @JavascriptInterface
        public void next() {
            String send;
            synchronized (flow) {
                send = waiting;
                waiting = null;
                pageReady = (send == null);
            }
            if (send != null) push(send);
        }

        @JavascriptInterface
        public void torch(final boolean lit) {
            ui.post(new Runnable() { @Override public void run() {
                try { if (camera != null) camera.getCameraControl().enableTorch(lit); } catch (Throwable t) { }
            } });
        }

        /* Focus on a point, given as parts of the camera box (0..1). */
        @JavascriptInterface
        public void focus(final double fx, final double fy) {
            ui.post(new Runnable() { @Override public void run() {
                try {
                    if (camera == null || view == null || view.getWidth() == 0) return;
                    MeteringPoint p = view.getMeteringPointFactory()
                        .createPoint((float) (fx * view.getWidth()), (float) (fy * view.getHeight()));
                    camera.getCameraControl().startFocusAndMetering(
                        new FocusMeteringAction.Builder(p, FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                            .setAutoCancelDuration(3, TimeUnit.SECONDS).build());
                } catch (Throwable t) { }
            } });
        }
    }

    // ------------------------------------------------------- page messages

    void tell(final String kind, final String json) {
        final String js = "window.dhScanNative&&window.dhScanNative('" + kind + "'," + (json == null ? "null" : json) + ")";
        ui.post(new Runnable() { @Override public void run() {
            try { web.evaluateJavascript(js, null); } catch (Throwable t) { }
        } });
    }

    void push(String frameJson) { tell("frame", frameJson); }

    void offer(String frameJson) {
        boolean now;
        synchronized (flow) {
            if (pageReady) { pageReady = false; now = true; }
            else { waiting = frameJson; now = false; }
        }
        if (now) push(frameJson);
    }

    // ----------------------------------------------------------- the camera

    /* The page's camera box: CSS pixels plus the page width, so the scale is
       measured, not assumed. */
    void placeUi(String rect) {
        try {
            JSONObject o = new JSONObject(rect);
            double vw = o.optDouble("vw", 0);
            double k = (vw > 0 && web.getWidth() > 0) ? web.getWidth() / vw
                     : act.getResources().getDisplayMetrics().density;
            rx = (int) Math.round(o.optDouble("x", 0) * k);
            ry = (int) Math.round(o.optDouble("y", 0) * k);
            rw = Math.max(1, (int) Math.round(o.optDouble("w", 1) * k));
            rh = Math.max(1, (int) Math.round(o.optDouble("h", 1) * k));
        } catch (Throwable t) { return; }
        if (view != null && view.getParent() != null) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) view.getLayoutParams();
            lp.width = rw; lp.height = rh; lp.leftMargin = rx; lp.topMargin = ry;
            view.setLayoutParams(lp);
        }
    }

    boolean hasCameraPermission() {
        return Build.VERSION.SDK_INT < 23
            || act.checkSelfPermission("android.permission.CAMERA") == PackageManager.PERMISSION_GRANTED;
    }

    void startUi(String rect) {
        placeUi(rect);
        on = true;
        synchronized (flow) { pageReady = true; waiting = null; }
        if (!hasCameraPermission()) {
            act.requestPermissions(new String[]{ "android.permission.CAMERA" }, PERM_REQ);
            return;
        }
        begin();
    }

    void onPermission(boolean granted) {
        if (!on) return;
        if (granted) begin();
        else { tell("denied", null); }
    }

    void begin() {
        try {
            if (view == null) {
                view = new PreviewView(act);
                view.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
                view.setScaleType(PreviewView.ScaleType.FILL_CENTER);
            }
            if (view.getParent() == null) {
                ViewGroup content = (ViewGroup) act.findViewById(android.R.id.content);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(rw, rh);
                lp.leftMargin = rx; lp.topMargin = ry;
                content.addView(view, 0, lp);    // index 0: behind the WebView
            }
            web.setBackgroundColor(Color.TRANSPARENT);
            if (rec == null) rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(act);
            f.addListener(new Runnable() {
                @Override public void run() {
                    try { provider = f.get(); bind(); }
                    catch (Throwable t) { tell("error", JSONObject.quote(String.valueOf(t))); }
                }
            }, uiExec);
        } catch (Throwable t) {
            tell("error", JSONObject.quote(String.valueOf(t)));
        }
    }

    void bind() {
        if (!on || provider == null || view == null) return;
        provider.unbindAll();
        // Both streams 16:9 at up to 1920x1080: the same view of the world, so
        // the page's box shows exactly what the reader sees.
        ResolutionSelector sel = new ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(new ResolutionStrategy(new Size(1920, 1080),
                ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
            .build();
        Preview preview = new Preview.Builder().setResolutionSelector(sel).build();
        preview.setSurfaceProvider(view.getSurfaceProvider());
        ImageAnalysis an = new ImageAnalysis.Builder()
            .setResolutionSelector(sel)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build();
        an.setAnalyzer(worker, new ImageAnalysis.Analyzer() {
            @Override public void analyze(@NonNull ImageProxy img) { look(img); }
        });
        camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, an);
        running = true;
        life.setCurrentState(actResumed ? Lifecycle.State.RESUMED : Lifecycle.State.CREATED);
        boolean torch = false;
        try { torch = camera.getCameraInfo().hasFlashUnit(); } catch (Throwable t) { }
        tell("ready", "{\"torch\":" + torch + "}");
    }

    void stopUi() {
        on = false;
        running = false;
        try { if (provider != null) provider.unbindAll(); } catch (Throwable t) { }
        camera = null;
        try { life.setCurrentState(Lifecycle.State.CREATED); } catch (Throwable t) { }
        if (view != null && view.getParent() != null) ((ViewGroup) view.getParent()).removeView(view);
        web.setBackgroundColor(0xFF000000);
        synchronized (flow) { pageReady = true; waiting = null; }
    }

    // Activity lifecycle: the camera only runs while the app is in front.
    void activityPaused() {
        actResumed = false;
        if (on) try { life.setCurrentState(Lifecycle.State.CREATED); } catch (Throwable t) { }
    }

    void activityResumed() {
        actResumed = true;
        if (on && camera != null) try { life.setCurrentState(Lifecycle.State.RESUMED); } catch (Throwable t) { }
    }

    void destroy() {
        stopUi();
        try { if (rec != null) rec.close(); } catch (Throwable t) { }
        rec = null;
        worker.shutdown();
    }

    // ------------------------------------------------------------ one frame

    @ExperimentalGetImage
    void look(final ImageProxy img) {
        final Image media = img.getImage();
        final TextRecognizer r = rec;
        if (media == null || !running || r == null) { img.close(); return; }
        final int rot = img.getImageInfo().getRotationDegrees();
        final int W = img.getWidth(), H = img.getHeight();
        final boolean side = (rot == 90 || rot == 270);
        final int UW = side ? H : W, UH = side ? W : H;     // the upright frame
        final int TH = Math.max(40, Math.round(UH * (float) THUMB_W / UW));
        final byte[] thumb;
        try {
            ImageProxy.PlaneProxy y = img.getPlanes()[0];
            thumb = greyThumb(y.getBuffer(), y.getRowStride(), y.getPixelStride(), W, H, rot, UW, UH, THUMB_W, TH);
        } catch (Throwable t) { img.close(); return; }
        Task<Text> task;
        try { task = r.process(InputImage.fromMediaImage(media, rot)); }
        catch (Throwable t) { img.close(); return; }
        task.addOnSuccessListener(worker, new OnSuccessListener<Text>() {
            @Override public void onSuccess(Text text) {
                if (!running) return;
                offer(frameJson(text, UW, UH, thumb, THUMB_W, TH));
            }
        }).addOnCompleteListener(worker, new OnCompleteListener<Text>() {
            @Override public void onComplete(@NonNull Task<Text> t) { img.close(); }
        });
    }

    /* The luma plane, turned upright and shrunk to tw x th by averaging a
       4x4 grid of samples per output pixel (smooth enough for the edge
       finder, cheap enough for every frame). */
    static byte[] greyThumb(ByteBuffer buf, int rowStride, int pixStride, int W, int H, int rot,
                            int UW, int UH, int tw, int th) {
        byte[] out = new byte[tw * th];
        float sx = UW / (float) tw, sy = UH / (float) th;
        int lim = buf.limit();
        for (int oy = 0; oy < th; oy++) {
            for (int ox = 0; ox < tw; ox++) {
                int sum = 0, n = 0;
                for (int j = 0; j < 4; j++) {
                    int uy = (int) ((oy + (j + 0.5f) / 4f) * sy);
                    if (uy >= UH) uy = UH - 1;
                    for (int i = 0; i < 4; i++) {
                        int ux = (int) ((ox + (i + 0.5f) / 4f) * sx);
                        if (ux >= UW) ux = UW - 1;
                        int x, yy;
                        switch (rot) {
                            case 90:  x = uy;          yy = H - 1 - ux; break;
                            case 180: x = W - 1 - ux;  yy = H - 1 - uy; break;
                            case 270: x = W - 1 - uy;  yy = ux;         break;
                            default:  x = ux;          yy = uy;
                        }
                        int at = yy * rowStride + x * pixStride;
                        if (at >= 0 && at < lim) { sum += buf.get(at) & 0xFF; n++; }
                    }
                }
                out[oy * tw + ox] = (byte) (n > 0 ? sum / n : 0);
            }
        }
        return out;
    }

    /* {fw, fh, tw, th, g: base64 grey, L: [[line, [8 corners], [[word, [8]]...]]...]}
       Corners clockwise from top-left, in thousandths of the upright frame. */
    static String frameJson(Text text, int UW, int UH, byte[] thumb, int tw, int th) {
        StringBuilder sb = new StringBuilder(thumb.length * 2);
        sb.append("{\"fw\":").append(UW).append(",\"fh\":").append(UH)
          .append(",\"tw\":").append(tw).append(",\"th\":").append(th)
          .append(",\"g\":\"").append(Base64.encodeToString(thumb, Base64.NO_WRAP)).append("\",\"L\":[");
        boolean firstLine = true;
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line ln : b.getLines()) {
                if (!firstLine) sb.append(',');
                firstLine = false;
                sb.append('[').append(JSONObject.quote(ln.getText())).append(',');
                corners(sb, ln.getCornerPoints(), UW, UH);
                sb.append(",[");
                boolean firstEl = true;
                for (Text.Element e : ln.getElements()) {
                    if (!firstEl) sb.append(',');
                    firstEl = false;
                    sb.append('[').append(JSONObject.quote(e.getText())).append(',');
                    corners(sb, e.getCornerPoints(), UW, UH);
                    sb.append(']');
                }
                sb.append("]]");
            }
        }
        sb.append("]}");
        return sb.toString();
    }

    static void corners(StringBuilder sb, Point[] p, int UW, int UH) {
        sb.append('[');
        for (int i = 0; i < 4; i++) {
            int x = 0, y = 0;
            if (p != null && p.length == 4 && p[i] != null) {
                x = Math.round(p[i].x * 1000f / UW);
                y = Math.round(p[i].y * 1000f / UH);
            }
            if (i > 0) sb.append(',');
            sb.append(x).append(',').append(y);
        }
        sb.append(']');
    }
}
